package pack2;

import pack1.Test;

class X extends Test {

	public void print_Msg() {
		display();//different package  subclass
	}

}

public class Checking {
	public static void main(String[] args) {
		Test test = new Test();
		test.display();//different  package non subclass
	}
}
