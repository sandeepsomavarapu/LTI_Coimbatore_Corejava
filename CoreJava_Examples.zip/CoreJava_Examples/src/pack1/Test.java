package pack1;

public class Test {
	public void display() {
		System.out.println("am from display method of Test class");
	}

	public static void main(String[] args) {
		Test test = new Test();
		test.display();//same class
	}
}

class A extends Test {

	public void m1() {
		display();//same package sub class

	}

}

class B {

	public void m2() {
		Test test = new Test();
		test.display();//same package non-subclass

	}

}