package com.lti.basics;

import java.util.Scanner;

class Test {

	public static void main(String args[]) {
		int values[]= {1,4,2,4,6,90};
		float[] salaries=new float[10];
		
		
		Scanner scan = new Scanner(System.in);// ctrl+shift+o

		System.out.println("Enter your first number for addition");
		int firstNum = scan.nextInt();
		System.out.println("Enter your second number for addition");
		int secondNum = scan.nextInt();
		System.out.println("Enter your gender :");
		String gender = scan.next();
		char gen = gender.charAt(0);

		System.out.println("Enter Your Full Name :");
		String fullName = scan.next();
		fullName=fullName.concat(scan.nextLine());
		System.out.println(fullName);

		int result = firstNum + secondNum;
		System.out.println(result + " " + gen);
		scan.close();

	}

}