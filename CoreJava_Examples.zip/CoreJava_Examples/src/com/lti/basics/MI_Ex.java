package com.lti.basics;

interface A {
	public abstract void m1();
}

interface B {
	public abstract void m1();
}

public class MI_Ex implements A, B {

	@Override
	public void m1() {
		System.out.println("am from child class");

	}

	public static void main(String[] args) {
		MI_Ex obj = new MI_Ex();
		obj.m1();
	}

}
