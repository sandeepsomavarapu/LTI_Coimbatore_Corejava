package com.lti.basics;

public class Methods_Example {

	public void addOfTwo(int a, int b) {//instance method
		System.out.println(a + b);
	}
	public static int subOfTwo(int a, int b) {//static method
		return a - b;
	}
	public void mulOfTwo() {
		int a = 12;
		int b = 32;
		System.out.println(a * b);
	}
	public static void main(String[] args) {
		System.out.println(Methods_Example.subOfTwo(12, 13));//static method calling by using classname
		int result = Methods_Example.subOfTwo(100, 13);
		System.out.println(result);
		Methods_Example obj = new Methods_Example();//object creation to create memory  space for instance properties 
		obj.mulOfTwo();
		obj.addOfTwo(2, 9);//calling instace method using object reference

	}

}
