package com.lti.basics;

interface SuperParent {
	void m4();// by default interface methods public abstract

	void m5();
}

abstract class Parent implements SuperParent{

	public void m2() {
		System.out.println("am from m2 method of Parent");
	}

	public abstract void m3();


}

public class AbstractionEx extends Parent{
	public void m1() {
		System.out.println("am from m1 method");
	}

	public static void main(String[] args) {
		AbstractionEx obj = new AbstractionEx();
		obj.m1();
		obj.m2();
		obj.m3();
	}
	@Override
	public void m3() {
		System.out.println("am from m3 method of AbstractionEx");
	}

	@Override
	public void m4() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void m5() {
		// TODO Auto-generated method stub
		
	}
}
