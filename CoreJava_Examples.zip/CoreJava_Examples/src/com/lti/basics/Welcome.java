package com.lti.basics;

public class Welcome {
	public static void main(String[] args) {//
		System.out.println("welcome to java");
		Welcome wel=new Welcome();
				wel.toString();
		
		
	}
}
//ctrl+space -->for suggestions
//ctrl+A & ctrl+shift+f-->for formatting
//ctrl+shift+o -->to organise imports