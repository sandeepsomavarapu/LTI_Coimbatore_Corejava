package com.lti.oops;

class Calculator

{
	public void add(int a, int b) {
		System.out.println("add of two int's : " + (a + b));
	}

	public void sub(int a, int b) {
		System.out.println("sub of two int's : " + (a - b));
	}
}

class Mobile_Calculator {
	public void mul(int a, int b) {
		System.out.println("mul of two int's : " + (a * b));
	}

}

class Laptop_Calculator extends Mobile_Calculator

{
	int age=23;
	public void div(int a, int b) {
		System.out.println("div of two int's : " + (a / b));
	}
}

public class Calci_Main extends Mobile_Calculator {
	public void sayHello() {
		System.out.println("hello everyone!!!!");
	}

	public static void main(String[] args) {
		Calci_Main obj = new Calci_Main();
		obj.sayHello();
		//obj.div(12, 3);
		obj.mul(12,13);
		//System.out.println(obj.age);
		
	}

}
